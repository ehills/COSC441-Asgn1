#ifndef DISK_H_
#define DISK_H_

extern void *disk_listen(void *);
extern int write_monitor(int);
extern int read_monitor(int);

#endif
