#ifndef MASTER_H_
#define MASTER_H_

extern int create_disk_threads(int);

#endif
