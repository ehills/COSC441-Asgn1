COSC441-Asgn1
=============

Assignment 1 - Multiple posix thread simulation

Author: Edward Hills
Date: 7/08/12

The main idea of this program is to implement a simulation in C of multiple disks in a RAID type configuration with multiple POSIX threads reading and writing.

